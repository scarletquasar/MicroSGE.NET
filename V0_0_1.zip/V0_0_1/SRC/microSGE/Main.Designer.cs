﻿namespace microSGE
{
    partial class Main
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Principal = new System.Windows.Forms.TabPage();
            this.RevertBtn = new System.Windows.Forms.Button();
            this.EditarBtn = new System.Windows.Forms.Button();
            this.LimparInfoBtn = new System.Windows.Forms.Button();
            this.EscolaPanel = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.DescText = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Logo = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.CNPJText = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.BairroText = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.CidadeText = new System.Windows.Forms.TextBox();
            this.UFText = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TelText = new System.Windows.Forms.TextBox();
            this.ZonaTxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.CepTxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.PrefText = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.NomeTxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ChangeLogoBtn = new System.Windows.Forms.Button();
            this.GravarBtn = new System.Windows.Forms.Button();
            this.Alunos = new System.Windows.Forms.TabPage();
            this.AlterarImagemAluno = new System.Windows.Forms.Button();
            this.SairAluno = new System.Windows.Forms.Button();
            this.GravarAluno = new System.Windows.Forms.Button();
            this.FindAluno = new System.Windows.Forms.Button();
            this.NovoAluno = new System.Windows.Forms.Button();
            this.NomePesquisaAluno = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.AlunosPainel = new System.Windows.Forms.Panel();
            this.ExcluirAluno = new System.Windows.Forms.Button();
            this.PastaAluno = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.ZonaAluno = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.UFAluno = new System.Windows.Forms.TextBox();
            this.infoAluno = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.EndAluno = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.RGAluno = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.NomeAluno = new System.Windows.Forms.TextBox();
            this.AlunoImagem = new System.Windows.Forms.PictureBox();
            this.Funcionários = new System.Windows.Forms.TabPage();
            this.AlterarFotoFunc = new System.Windows.Forms.Button();
            this.SairFunc = new System.Windows.Forms.Button();
            this.GravarFunc = new System.Windows.Forms.Button();
            this.FuncPesquisa = new System.Windows.Forms.Button();
            this.NovoFunc = new System.Windows.Forms.Button();
            this.PesquisaFuncTxt = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.FuncPanel = new System.Windows.Forms.Panel();
            this.ExcluirFunc = new System.Windows.Forms.Button();
            this.FuncPasta = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.ZonaFunc = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.UFFunc = new System.Windows.Forms.TextBox();
            this.DescFunc = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.EndFunc = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.RGFunc = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.NomeFunc = new System.Windows.Forms.TextBox();
            this.FuncImagem = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.Principal.SuspendLayout();
            this.EscolaPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).BeginInit();
            this.Alunos.SuspendLayout();
            this.AlunosPainel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AlunoImagem)).BeginInit();
            this.Funcionários.SuspendLayout();
            this.FuncPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FuncImagem)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Principal);
            this.tabControl1.Controls.Add(this.Alunos);
            this.tabControl1.Controls.Add(this.Funcionários);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 405);
            this.tabControl1.TabIndex = 0;
            // 
            // Principal
            // 
            this.Principal.Controls.Add(this.RevertBtn);
            this.Principal.Controls.Add(this.EditarBtn);
            this.Principal.Controls.Add(this.LimparInfoBtn);
            this.Principal.Controls.Add(this.EscolaPanel);
            this.Principal.Controls.Add(this.ChangeLogoBtn);
            this.Principal.Controls.Add(this.GravarBtn);
            this.Principal.Location = new System.Drawing.Point(4, 22);
            this.Principal.Name = "Principal";
            this.Principal.Padding = new System.Windows.Forms.Padding(3);
            this.Principal.Size = new System.Drawing.Size(768, 379);
            this.Principal.TabIndex = 0;
            this.Principal.Text = "Principal";
            this.Principal.UseVisualStyleBackColor = true;
            // 
            // RevertBtn
            // 
            this.RevertBtn.Enabled = false;
            this.RevertBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RevertBtn.Image = ((System.Drawing.Image)(resources.GetObject("RevertBtn.Image")));
            this.RevertBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.RevertBtn.Location = new System.Drawing.Point(553, 328);
            this.RevertBtn.Name = "RevertBtn";
            this.RevertBtn.Size = new System.Drawing.Size(111, 44);
            this.RevertBtn.TabIndex = 58;
            this.RevertBtn.Text = "REVERTER CAMPOS";
            this.RevertBtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.RevertBtn.UseVisualStyleBackColor = true;
            this.RevertBtn.Click += new System.EventHandler(this.RevertBtn_Click);
            // 
            // EditarBtn
            // 
            this.EditarBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditarBtn.Image = ((System.Drawing.Image)(resources.GetObject("EditarBtn.Image")));
            this.EditarBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.EditarBtn.Location = new System.Drawing.Point(670, 328);
            this.EditarBtn.Name = "EditarBtn";
            this.EditarBtn.Size = new System.Drawing.Size(92, 44);
            this.EditarBtn.TabIndex = 26;
            this.EditarBtn.Text = "EDITAR";
            this.EditarBtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.EditarBtn.UseVisualStyleBackColor = true;
            this.EditarBtn.Click += new System.EventHandler(this.EditarBtn_Click);
            // 
            // LimparInfoBtn
            // 
            this.LimparInfoBtn.Enabled = false;
            this.LimparInfoBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LimparInfoBtn.Image = ((System.Drawing.Image)(resources.GetObject("LimparInfoBtn.Image")));
            this.LimparInfoBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LimparInfoBtn.Location = new System.Drawing.Point(418, 328);
            this.LimparInfoBtn.Name = "LimparInfoBtn";
            this.LimparInfoBtn.Size = new System.Drawing.Size(129, 44);
            this.LimparInfoBtn.TabIndex = 57;
            this.LimparInfoBtn.Text = "LIMPAR INFORMAÇÕES";
            this.LimparInfoBtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.LimparInfoBtn.UseVisualStyleBackColor = true;
            this.LimparInfoBtn.Click += new System.EventHandler(this.LimparInfoBtn_Click);
            // 
            // EscolaPanel
            // 
            this.EscolaPanel.Controls.Add(this.label11);
            this.EscolaPanel.Controls.Add(this.DescText);
            this.EscolaPanel.Controls.Add(this.label10);
            this.EscolaPanel.Controls.Add(this.Logo);
            this.EscolaPanel.Controls.Add(this.label9);
            this.EscolaPanel.Controls.Add(this.CNPJText);
            this.EscolaPanel.Controls.Add(this.label8);
            this.EscolaPanel.Controls.Add(this.BairroText);
            this.EscolaPanel.Controls.Add(this.label7);
            this.EscolaPanel.Controls.Add(this.CidadeText);
            this.EscolaPanel.Controls.Add(this.UFText);
            this.EscolaPanel.Controls.Add(this.label6);
            this.EscolaPanel.Controls.Add(this.label5);
            this.EscolaPanel.Controls.Add(this.TelText);
            this.EscolaPanel.Controls.Add(this.ZonaTxt);
            this.EscolaPanel.Controls.Add(this.label4);
            this.EscolaPanel.Controls.Add(this.CepTxt);
            this.EscolaPanel.Controls.Add(this.label3);
            this.EscolaPanel.Controls.Add(this.PrefText);
            this.EscolaPanel.Controls.Add(this.label2);
            this.EscolaPanel.Controls.Add(this.NomeTxt);
            this.EscolaPanel.Controls.Add(this.label1);
            this.EscolaPanel.Enabled = false;
            this.EscolaPanel.Location = new System.Drawing.Point(0, 0);
            this.EscolaPanel.Name = "EscolaPanel";
            this.EscolaPanel.Size = new System.Drawing.Size(768, 322);
            this.EscolaPanel.TabIndex = 27;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(212, 96);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 20);
            this.label11.TabIndex = 44;
            this.label11.Text = "DESCRIÇÃO";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DescText
            // 
            this.DescText.Location = new System.Drawing.Point(215, 119);
            this.DescText.Multiline = true;
            this.DescText.Name = "DescText";
            this.DescText.Size = new System.Drawing.Size(547, 200);
            this.DescText.TabIndex = 43;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 96);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 20);
            this.label10.TabIndex = 42;
            this.label10.Text = "LOGO";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Logo
            // 
            this.Logo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Logo.Location = new System.Drawing.Point(9, 119);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(200, 200);
            this.Logo.TabIndex = 41;
            this.Logo.TabStop = false;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(522, 49);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 20);
            this.label9.TabIndex = 40;
            this.label9.Text = "CNPJ";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CNPJText
            // 
            this.CNPJText.Location = new System.Drawing.Point(525, 72);
            this.CNPJText.Name = "CNPJText";
            this.CNPJText.Size = new System.Drawing.Size(237, 20);
            this.CNPJText.TabIndex = 39;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(292, 49);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 20);
            this.label8.TabIndex = 38;
            this.label8.Text = "BAIRRO";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BairroText
            // 
            this.BairroText.Location = new System.Drawing.Point(295, 72);
            this.BairroText.Name = "BairroText";
            this.BairroText.Size = new System.Drawing.Size(224, 20);
            this.BairroText.TabIndex = 37;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(62, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 20);
            this.label7.TabIndex = 36;
            this.label7.Text = "MUNICÍPIO";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CidadeText
            // 
            this.CidadeText.Location = new System.Drawing.Point(65, 72);
            this.CidadeText.Name = "CidadeText";
            this.CidadeText.Size = new System.Drawing.Size(224, 20);
            this.CidadeText.TabIndex = 35;
            // 
            // UFText
            // 
            this.UFText.Location = new System.Drawing.Point(9, 72);
            this.UFText.Name = "UFText";
            this.UFText.Size = new System.Drawing.Size(50, 20);
            this.UFText.TabIndex = 34;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 20);
            this.label6.TabIndex = 33;
            this.label6.Text = "UF";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(588, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 20);
            this.label5.TabIndex = 32;
            this.label5.Text = "NÚMERO DE TELEFONE";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TelText
            // 
            this.TelText.Location = new System.Drawing.Point(591, 26);
            this.TelText.Name = "TelText";
            this.TelText.Size = new System.Drawing.Size(171, 20);
            this.TelText.TabIndex = 31;
            // 
            // ZonaTxt
            // 
            this.ZonaTxt.Location = new System.Drawing.Point(318, 26);
            this.ZonaTxt.Name = "ZonaTxt";
            this.ZonaTxt.Size = new System.Drawing.Size(73, 20);
            this.ZonaTxt.TabIndex = 30;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(315, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 20);
            this.label4.TabIndex = 29;
            this.label4.Text = "ZONA";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CepTxt
            // 
            this.CepTxt.Location = new System.Drawing.Point(239, 26);
            this.CepTxt.Name = "CepTxt";
            this.CepTxt.Size = new System.Drawing.Size(73, 20);
            this.CepTxt.TabIndex = 28;
            this.CepTxt.TextChanged += new System.EventHandler(this.CepTxt_TextChanged);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(236, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 20);
            this.label3.TabIndex = 27;
            this.label3.Text = "CEP";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PrefText
            // 
            this.PrefText.Location = new System.Drawing.Point(397, 26);
            this.PrefText.Name = "PrefText";
            this.PrefText.Size = new System.Drawing.Size(188, 20);
            this.PrefText.TabIndex = 26;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(394, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 20);
            this.label2.TabIndex = 25;
            this.label2.Text = "PREFIXO DA INSTITUIÇÃO";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // NomeTxt
            // 
            this.NomeTxt.Location = new System.Drawing.Point(9, 26);
            this.NomeTxt.Name = "NomeTxt";
            this.NomeTxt.Size = new System.Drawing.Size(224, 20);
            this.NomeTxt.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 20);
            this.label1.TabIndex = 23;
            this.label1.Text = "NOME DA INSTITUIÇÃO";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ChangeLogoBtn
            // 
            this.ChangeLogoBtn.Enabled = false;
            this.ChangeLogoBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChangeLogoBtn.Image = ((System.Drawing.Image)(resources.GetObject("ChangeLogoBtn.Image")));
            this.ChangeLogoBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ChangeLogoBtn.Location = new System.Drawing.Point(286, 328);
            this.ChangeLogoBtn.Name = "ChangeLogoBtn";
            this.ChangeLogoBtn.Size = new System.Drawing.Size(126, 44);
            this.ChangeLogoBtn.TabIndex = 25;
            this.ChangeLogoBtn.Text = "ALTERAR LOGO";
            this.ChangeLogoBtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ChangeLogoBtn.UseVisualStyleBackColor = true;
            this.ChangeLogoBtn.Click += new System.EventHandler(this.ChangeLogoBtn_Click_1);
            // 
            // GravarBtn
            // 
            this.GravarBtn.Enabled = false;
            this.GravarBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GravarBtn.Image = ((System.Drawing.Image)(resources.GetObject("GravarBtn.Image")));
            this.GravarBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.GravarBtn.Location = new System.Drawing.Point(187, 328);
            this.GravarBtn.Name = "GravarBtn";
            this.GravarBtn.Size = new System.Drawing.Size(93, 44);
            this.GravarBtn.TabIndex = 23;
            this.GravarBtn.Text = "GRAVAR";
            this.GravarBtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.GravarBtn.UseVisualStyleBackColor = true;
            this.GravarBtn.Click += new System.EventHandler(this.GravarBtn_Click);
            // 
            // Alunos
            // 
            this.Alunos.Controls.Add(this.AlterarImagemAluno);
            this.Alunos.Controls.Add(this.SairAluno);
            this.Alunos.Controls.Add(this.GravarAluno);
            this.Alunos.Controls.Add(this.FindAluno);
            this.Alunos.Controls.Add(this.NovoAluno);
            this.Alunos.Controls.Add(this.NomePesquisaAluno);
            this.Alunos.Controls.Add(this.label13);
            this.Alunos.Controls.Add(this.AlunosPainel);
            this.Alunos.Location = new System.Drawing.Point(4, 22);
            this.Alunos.Name = "Alunos";
            this.Alunos.Padding = new System.Windows.Forms.Padding(3);
            this.Alunos.Size = new System.Drawing.Size(768, 379);
            this.Alunos.TabIndex = 1;
            this.Alunos.Text = "Alunos";
            this.Alunos.UseVisualStyleBackColor = true;
            // 
            // AlterarImagemAluno
            // 
            this.AlterarImagemAluno.Enabled = false;
            this.AlterarImagemAluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AlterarImagemAluno.Image = ((System.Drawing.Image)(resources.GetObject("AlterarImagemAluno.Image")));
            this.AlterarImagemAluno.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AlterarImagemAluno.Location = new System.Drawing.Point(95, 329);
            this.AlterarImagemAluno.Name = "AlterarImagemAluno";
            this.AlterarImagemAluno.Size = new System.Drawing.Size(128, 44);
            this.AlterarImagemAluno.TabIndex = 68;
            this.AlterarImagemAluno.Text = "ALTERAR FOTO";
            this.AlterarImagemAluno.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.AlterarImagemAluno.UseVisualStyleBackColor = true;
            this.AlterarImagemAluno.Click += new System.EventHandler(this.AlterarImagemAluno_Click);
            // 
            // SairAluno
            // 
            this.SairAluno.Enabled = false;
            this.SairAluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SairAluno.Image = ((System.Drawing.Image)(resources.GetObject("SairAluno.Image")));
            this.SairAluno.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SairAluno.Location = new System.Drawing.Point(229, 329);
            this.SairAluno.Name = "SairAluno";
            this.SairAluno.Size = new System.Drawing.Size(97, 44);
            this.SairAluno.TabIndex = 60;
            this.SairAluno.Text = "SAIR SEM GRAVAR";
            this.SairAluno.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SairAluno.UseVisualStyleBackColor = true;
            this.SairAluno.Click += new System.EventHandler(this.SairAluno_Click);
            // 
            // GravarAluno
            // 
            this.GravarAluno.Enabled = false;
            this.GravarAluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GravarAluno.Image = ((System.Drawing.Image)(resources.GetObject("GravarAluno.Image")));
            this.GravarAluno.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.GravarAluno.Location = new System.Drawing.Point(332, 329);
            this.GravarAluno.Name = "GravarAluno";
            this.GravarAluno.Size = new System.Drawing.Size(92, 44);
            this.GravarAluno.TabIndex = 59;
            this.GravarAluno.Text = "GRAVAR E SAIR DO ALUNO";
            this.GravarAluno.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.GravarAluno.UseVisualStyleBackColor = true;
            this.GravarAluno.Click += new System.EventHandler(this.GravarAluno_Click);
            // 
            // FindAluno
            // 
            this.FindAluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FindAluno.Image = ((System.Drawing.Image)(resources.GetObject("FindAluno.Image")));
            this.FindAluno.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FindAluno.Location = new System.Drawing.Point(641, 3);
            this.FindAluno.Name = "FindAluno";
            this.FindAluno.Size = new System.Drawing.Size(121, 44);
            this.FindAluno.TabIndex = 31;
            this.FindAluno.Text = "PESQUISAR";
            this.FindAluno.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.FindAluno.UseVisualStyleBackColor = true;
            this.FindAluno.Click += new System.EventHandler(this.FindAluno_Click);
            // 
            // NovoAluno
            // 
            this.NovoAluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NovoAluno.Image = ((System.Drawing.Image)(resources.GetObject("NovoAluno.Image")));
            this.NovoAluno.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NovoAluno.Location = new System.Drawing.Point(9, 329);
            this.NovoAluno.Name = "NovoAluno";
            this.NovoAluno.Size = new System.Drawing.Size(80, 44);
            this.NovoAluno.TabIndex = 58;
            this.NovoAluno.Text = "NOVO ALUNO";
            this.NovoAluno.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.NovoAluno.UseVisualStyleBackColor = true;
            this.NovoAluno.Click += new System.EventHandler(this.NovoAluno_Click);
            // 
            // NomePesquisaAluno
            // 
            this.NomePesquisaAluno.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.NomePesquisaAluno.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.NomePesquisaAluno.FormattingEnabled = true;
            this.NomePesquisaAluno.Location = new System.Drawing.Point(12, 26);
            this.NomePesquisaAluno.Name = "NomePesquisaAluno";
            this.NomePesquisaAluno.Size = new System.Drawing.Size(623, 21);
            this.NomePesquisaAluno.TabIndex = 30;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label13.Location = new System.Drawing.Point(9, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(626, 20);
            this.label13.TabIndex = 29;
            this.label13.Text = "NOME DO ALUNO";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // AlunosPainel
            // 
            this.AlunosPainel.Controls.Add(this.ExcluirAluno);
            this.AlunosPainel.Controls.Add(this.PastaAluno);
            this.AlunosPainel.Controls.Add(this.label21);
            this.AlunosPainel.Controls.Add(this.ZonaAluno);
            this.AlunosPainel.Controls.Add(this.label14);
            this.AlunosPainel.Controls.Add(this.UFAluno);
            this.AlunosPainel.Controls.Add(this.infoAluno);
            this.AlunosPainel.Controls.Add(this.label20);
            this.AlunosPainel.Controls.Add(this.EndAluno);
            this.AlunosPainel.Controls.Add(this.label19);
            this.AlunosPainel.Controls.Add(this.RGAluno);
            this.AlunosPainel.Controls.Add(this.label17);
            this.AlunosPainel.Controls.Add(this.label15);
            this.AlunosPainel.Controls.Add(this.NomeAluno);
            this.AlunosPainel.Controls.Add(this.AlunoImagem);
            this.AlunosPainel.Enabled = false;
            this.AlunosPainel.Location = new System.Drawing.Point(6, 53);
            this.AlunosPainel.Name = "AlunosPainel";
            this.AlunosPainel.Size = new System.Drawing.Size(756, 270);
            this.AlunosPainel.TabIndex = 28;
            // 
            // ExcluirAluno
            // 
            this.ExcluirAluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExcluirAluno.Image = ((System.Drawing.Image)(resources.GetObject("ExcluirAluno.Image")));
            this.ExcluirAluno.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ExcluirAluno.Location = new System.Drawing.Point(264, 109);
            this.ExcluirAluno.Name = "ExcluirAluno";
            this.ExcluirAluno.Size = new System.Drawing.Size(96, 44);
            this.ExcluirAluno.TabIndex = 56;
            this.ExcluirAluno.Text = "EXCLUIR ALUNO";
            this.ExcluirAluno.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ExcluirAluno.UseVisualStyleBackColor = true;
            this.ExcluirAluno.Click += new System.EventHandler(this.ExcluirAluno_Click);
            // 
            // PastaAluno
            // 
            this.PastaAluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PastaAluno.Image = ((System.Drawing.Image)(resources.GetObject("PastaAluno.Image")));
            this.PastaAluno.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PastaAluno.Location = new System.Drawing.Point(162, 109);
            this.PastaAluno.Name = "PastaAluno";
            this.PastaAluno.Size = new System.Drawing.Size(96, 44);
            this.PastaAluno.TabIndex = 32;
            this.PastaAluno.Text = "PASTA DO ALUNO";
            this.PastaAluno.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.PastaAluno.UseVisualStyleBackColor = true;
            this.PastaAluno.Click += new System.EventHandler(this.PastaAluno_Click);
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(483, 49);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(42, 20);
            this.label21.TabIndex = 55;
            this.label21.Text = "ZONA";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ZonaAluno
            // 
            this.ZonaAluno.Location = new System.Drawing.Point(486, 72);
            this.ZonaAluno.Name = "ZonaAluno";
            this.ZonaAluno.Size = new System.Drawing.Size(153, 20);
            this.ZonaAluno.TabIndex = 54;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(414, 49);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(27, 20);
            this.label14.TabIndex = 53;
            this.label14.Text = "UF";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // UFAluno
            // 
            this.UFAluno.Location = new System.Drawing.Point(417, 72);
            this.UFAluno.Name = "UFAluno";
            this.UFAluno.Size = new System.Drawing.Size(63, 20);
            this.UFAluno.TabIndex = 52;
            // 
            // infoAluno
            // 
            this.infoAluno.Location = new System.Drawing.Point(6, 179);
            this.infoAluno.Multiline = true;
            this.infoAluno.Name = "infoAluno";
            this.infoAluno.Size = new System.Drawing.Size(747, 88);
            this.infoAluno.TabIndex = 51;
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(3, 156);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(312, 20);
            this.label20.TabIndex = 50;
            this.label20.Text = "INFORMAÇÕES ADICIONAIS";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // EndAluno
            // 
            this.EndAluno.Location = new System.Drawing.Point(162, 72);
            this.EndAluno.Name = "EndAluno";
            this.EndAluno.Size = new System.Drawing.Size(246, 20);
            this.EndAluno.TabIndex = 49;
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(159, 49);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(83, 20);
            this.label19.TabIndex = 48;
            this.label19.Text = "ENDEREÇO";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // RGAluno
            // 
            this.RGAluno.Location = new System.Drawing.Point(345, 26);
            this.RGAluno.Name = "RGAluno";
            this.RGAluno.Size = new System.Drawing.Size(363, 20);
            this.RGAluno.TabIndex = 47;
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(342, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(47, 20);
            this.label17.TabIndex = 46;
            this.label17.Text = "RG";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label15.Location = new System.Drawing.Point(159, 3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 20);
            this.label15.TabIndex = 33;
            this.label15.Text = "NOME";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // NomeAluno
            // 
            this.NomeAluno.Location = new System.Drawing.Point(162, 26);
            this.NomeAluno.Name = "NomeAluno";
            this.NomeAluno.Size = new System.Drawing.Size(177, 20);
            this.NomeAluno.TabIndex = 43;
            // 
            // AlunoImagem
            // 
            this.AlunoImagem.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AlunoImagem.Location = new System.Drawing.Point(3, 3);
            this.AlunoImagem.Name = "AlunoImagem";
            this.AlunoImagem.Size = new System.Drawing.Size(150, 150);
            this.AlunoImagem.TabIndex = 42;
            this.AlunoImagem.TabStop = false;
            // 
            // Funcionários
            // 
            this.Funcionários.Controls.Add(this.AlterarFotoFunc);
            this.Funcionários.Controls.Add(this.SairFunc);
            this.Funcionários.Controls.Add(this.GravarFunc);
            this.Funcionários.Controls.Add(this.FuncPesquisa);
            this.Funcionários.Controls.Add(this.NovoFunc);
            this.Funcionários.Controls.Add(this.PesquisaFuncTxt);
            this.Funcionários.Controls.Add(this.label25);
            this.Funcionários.Controls.Add(this.FuncPanel);
            this.Funcionários.Location = new System.Drawing.Point(4, 22);
            this.Funcionários.Name = "Funcionários";
            this.Funcionários.Size = new System.Drawing.Size(768, 379);
            this.Funcionários.TabIndex = 2;
            this.Funcionários.Text = "Funcionários";
            this.Funcionários.UseVisualStyleBackColor = true;
            // 
            // AlterarFotoFunc
            // 
            this.AlterarFotoFunc.Enabled = false;
            this.AlterarFotoFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AlterarFotoFunc.Image = ((System.Drawing.Image)(resources.GetObject("AlterarFotoFunc.Image")));
            this.AlterarFotoFunc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AlterarFotoFunc.Location = new System.Drawing.Point(176, 330);
            this.AlterarFotoFunc.Name = "AlterarFotoFunc";
            this.AlterarFotoFunc.Size = new System.Drawing.Size(128, 44);
            this.AlterarFotoFunc.TabIndex = 67;
            this.AlterarFotoFunc.Text = "ALTERAR FOTO";
            this.AlterarFotoFunc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.AlterarFotoFunc.UseVisualStyleBackColor = true;
            this.AlterarFotoFunc.Click += new System.EventHandler(this.AlterarFotoFunc_Click);
            // 
            // SairFunc
            // 
            this.SairFunc.Enabled = false;
            this.SairFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SairFunc.Image = ((System.Drawing.Image)(resources.GetObject("SairFunc.Image")));
            this.SairFunc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SairFunc.Location = new System.Drawing.Point(470, 330);
            this.SairFunc.Name = "SairFunc";
            this.SairFunc.Size = new System.Drawing.Size(97, 44);
            this.SairFunc.TabIndex = 66;
            this.SairFunc.Text = "SAIR SEM GRAVAR";
            this.SairFunc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SairFunc.UseVisualStyleBackColor = true;
            this.SairFunc.Click += new System.EventHandler(this.SairFunc_Click);
            // 
            // GravarFunc
            // 
            this.GravarFunc.Enabled = false;
            this.GravarFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GravarFunc.Image = ((System.Drawing.Image)(resources.GetObject("GravarFunc.Image")));
            this.GravarFunc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.GravarFunc.Location = new System.Drawing.Point(310, 330);
            this.GravarFunc.Name = "GravarFunc";
            this.GravarFunc.Size = new System.Drawing.Size(154, 44);
            this.GravarFunc.TabIndex = 65;
            this.GravarFunc.Text = "GRAVAR E SAIR DO FUNCIONÁRIO";
            this.GravarFunc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.GravarFunc.UseVisualStyleBackColor = true;
            this.GravarFunc.Click += new System.EventHandler(this.GravarFunc_Click);
            // 
            // FuncPesquisa
            // 
            this.FuncPesquisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FuncPesquisa.Image = ((System.Drawing.Image)(resources.GetObject("FuncPesquisa.Image")));
            this.FuncPesquisa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FuncPesquisa.Location = new System.Drawing.Point(640, 4);
            this.FuncPesquisa.Name = "FuncPesquisa";
            this.FuncPesquisa.Size = new System.Drawing.Size(121, 44);
            this.FuncPesquisa.TabIndex = 63;
            this.FuncPesquisa.Text = "PESQUISAR";
            this.FuncPesquisa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.FuncPesquisa.UseVisualStyleBackColor = true;
            this.FuncPesquisa.Click += new System.EventHandler(this.FuncPesquisa_Click);
            // 
            // NovoFunc
            // 
            this.NovoFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NovoFunc.Image = ((System.Drawing.Image)(resources.GetObject("NovoFunc.Image")));
            this.NovoFunc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NovoFunc.Location = new System.Drawing.Point(8, 330);
            this.NovoFunc.Name = "NovoFunc";
            this.NovoFunc.Size = new System.Drawing.Size(162, 44);
            this.NovoFunc.TabIndex = 64;
            this.NovoFunc.Text = "NOVO FUNCIONÁRIO";
            this.NovoFunc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.NovoFunc.UseVisualStyleBackColor = true;
            this.NovoFunc.Click += new System.EventHandler(this.NovoFunc_Click);
            // 
            // PesquisaFuncTxt
            // 
            this.PesquisaFuncTxt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.PesquisaFuncTxt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.PesquisaFuncTxt.FormattingEnabled = true;
            this.PesquisaFuncTxt.Location = new System.Drawing.Point(11, 27);
            this.PesquisaFuncTxt.Name = "PesquisaFuncTxt";
            this.PesquisaFuncTxt.Size = new System.Drawing.Size(623, 21);
            this.PesquisaFuncTxt.TabIndex = 62;
            // 
            // label25
            // 
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label25.Location = new System.Drawing.Point(8, 4);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(626, 20);
            this.label25.TabIndex = 61;
            this.label25.Text = "NOME DO FUNCIONÁRIO";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FuncPanel
            // 
            this.FuncPanel.Controls.Add(this.ExcluirFunc);
            this.FuncPanel.Controls.Add(this.FuncPasta);
            this.FuncPanel.Controls.Add(this.label12);
            this.FuncPanel.Controls.Add(this.ZonaFunc);
            this.FuncPanel.Controls.Add(this.label16);
            this.FuncPanel.Controls.Add(this.UFFunc);
            this.FuncPanel.Controls.Add(this.DescFunc);
            this.FuncPanel.Controls.Add(this.label18);
            this.FuncPanel.Controls.Add(this.EndFunc);
            this.FuncPanel.Controls.Add(this.label22);
            this.FuncPanel.Controls.Add(this.RGFunc);
            this.FuncPanel.Controls.Add(this.label23);
            this.FuncPanel.Controls.Add(this.label24);
            this.FuncPanel.Controls.Add(this.NomeFunc);
            this.FuncPanel.Controls.Add(this.FuncImagem);
            this.FuncPanel.Enabled = false;
            this.FuncPanel.Location = new System.Drawing.Point(6, 54);
            this.FuncPanel.Name = "FuncPanel";
            this.FuncPanel.Size = new System.Drawing.Size(756, 270);
            this.FuncPanel.TabIndex = 29;
            // 
            // ExcluirFunc
            // 
            this.ExcluirFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExcluirFunc.Image = ((System.Drawing.Image)(resources.GetObject("ExcluirFunc.Image")));
            this.ExcluirFunc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ExcluirFunc.Location = new System.Drawing.Point(289, 109);
            this.ExcluirFunc.Name = "ExcluirFunc";
            this.ExcluirFunc.Size = new System.Drawing.Size(126, 44);
            this.ExcluirFunc.TabIndex = 56;
            this.ExcluirFunc.Text = "EXCLUIR FUNCIONÁRIO";
            this.ExcluirFunc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ExcluirFunc.UseVisualStyleBackColor = true;
            this.ExcluirFunc.Click += new System.EventHandler(this.ExcluirFunc_Click);
            // 
            // FuncPasta
            // 
            this.FuncPasta.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FuncPasta.Image = ((System.Drawing.Image)(resources.GetObject("FuncPasta.Image")));
            this.FuncPasta.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FuncPasta.Location = new System.Drawing.Point(162, 109);
            this.FuncPasta.Name = "FuncPasta";
            this.FuncPasta.Size = new System.Drawing.Size(121, 44);
            this.FuncPasta.TabIndex = 32;
            this.FuncPasta.Text = "PASTA DO FUNCIONÁRIO";
            this.FuncPasta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.FuncPasta.UseVisualStyleBackColor = true;
            this.FuncPasta.Click += new System.EventHandler(this.FuncPasta_Click);
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(483, 49);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 20);
            this.label12.TabIndex = 55;
            this.label12.Text = "ZONA";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ZonaFunc
            // 
            this.ZonaFunc.Location = new System.Drawing.Point(486, 72);
            this.ZonaFunc.Name = "ZonaFunc";
            this.ZonaFunc.Size = new System.Drawing.Size(89, 20);
            this.ZonaFunc.TabIndex = 54;
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(414, 49);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(27, 20);
            this.label16.TabIndex = 53;
            this.label16.Text = "UF";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // UFFunc
            // 
            this.UFFunc.Location = new System.Drawing.Point(417, 72);
            this.UFFunc.Name = "UFFunc";
            this.UFFunc.Size = new System.Drawing.Size(63, 20);
            this.UFFunc.TabIndex = 52;
            // 
            // DescFunc
            // 
            this.DescFunc.Location = new System.Drawing.Point(6, 179);
            this.DescFunc.Multiline = true;
            this.DescFunc.Name = "DescFunc";
            this.DescFunc.Size = new System.Drawing.Size(747, 88);
            this.DescFunc.TabIndex = 51;
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(3, 156);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(312, 20);
            this.label18.TabIndex = 50;
            this.label18.Text = "INFORMAÇÕES ADICIONAIS";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // EndFunc
            // 
            this.EndFunc.Location = new System.Drawing.Point(162, 72);
            this.EndFunc.Name = "EndFunc";
            this.EndFunc.Size = new System.Drawing.Size(246, 20);
            this.EndFunc.TabIndex = 49;
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(159, 49);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(83, 20);
            this.label22.TabIndex = 48;
            this.label22.Text = "ENDEREÇO";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // RGFunc
            // 
            this.RGFunc.Location = new System.Drawing.Point(345, 26);
            this.RGFunc.Name = "RGFunc";
            this.RGFunc.Size = new System.Drawing.Size(363, 20);
            this.RGFunc.TabIndex = 47;
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(342, 3);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(47, 20);
            this.label23.TabIndex = 46;
            this.label23.Text = "RG";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label24.Location = new System.Drawing.Point(159, 3);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(47, 20);
            this.label24.TabIndex = 33;
            this.label24.Text = "NOME";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // NomeFunc
            // 
            this.NomeFunc.Location = new System.Drawing.Point(162, 26);
            this.NomeFunc.Name = "NomeFunc";
            this.NomeFunc.Size = new System.Drawing.Size(177, 20);
            this.NomeFunc.TabIndex = 43;
            // 
            // FuncImagem
            // 
            this.FuncImagem.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FuncImagem.Location = new System.Drawing.Point(3, 3);
            this.FuncImagem.Name = "FuncImagem";
            this.FuncImagem.Size = new System.Drawing.Size(150, 150);
            this.FuncImagem.TabIndex = 42;
            this.FuncImagem.TabStop = false;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 421);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(816, 460);
            this.MinimumSize = new System.Drawing.Size(816, 460);
            this.Name = "Main";
            this.Text = "microSGE - Sistema de Gerenciamento Escolar";
            this.tabControl1.ResumeLayout(false);
            this.Principal.ResumeLayout(false);
            this.EscolaPanel.ResumeLayout(false);
            this.EscolaPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).EndInit();
            this.Alunos.ResumeLayout(false);
            this.AlunosPainel.ResumeLayout(false);
            this.AlunosPainel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AlunoImagem)).EndInit();
            this.Funcionários.ResumeLayout(false);
            this.FuncPanel.ResumeLayout(false);
            this.FuncPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FuncImagem)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Principal;
        private System.Windows.Forms.TabPage Alunos;
        private System.Windows.Forms.TabPage Funcionários;
        private System.Windows.Forms.Button EditarBtn;
        private System.Windows.Forms.Button ChangeLogoBtn;
        private System.Windows.Forms.Button GravarBtn;
        private System.Windows.Forms.Panel EscolaPanel;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox DescText;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox Logo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox CNPJText;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox BairroText;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox CidadeText;
        private System.Windows.Forms.TextBox UFText;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TelText;
        private System.Windows.Forms.TextBox ZonaTxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox CepTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox PrefText;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox NomeTxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel AlunosPainel;
        private System.Windows.Forms.PictureBox AlunoImagem;
        private System.Windows.Forms.TextBox RGAluno;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox NomeAluno;
        private System.Windows.Forms.TextBox EndAluno;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox infoAluno;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button FindAluno;
        private System.Windows.Forms.ComboBox NomePesquisaAluno;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox ZonaAluno;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox UFAluno;
        private System.Windows.Forms.Button PastaAluno;
        private System.Windows.Forms.Button ExcluirAluno;
        private System.Windows.Forms.Button LimparInfoBtn;
        private System.Windows.Forms.Button RevertBtn;
        private System.Windows.Forms.Button NovoAluno;
        private System.Windows.Forms.Button GravarAluno;
        private System.Windows.Forms.Button SairAluno;
        private System.Windows.Forms.Panel FuncPanel;
        private System.Windows.Forms.Button ExcluirFunc;
        private System.Windows.Forms.Button FuncPasta;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox ZonaFunc;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox UFFunc;
        private System.Windows.Forms.TextBox DescFunc;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox EndFunc;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox RGFunc;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox NomeFunc;
        private System.Windows.Forms.PictureBox FuncImagem;
        private System.Windows.Forms.Button SairFunc;
        private System.Windows.Forms.Button GravarFunc;
        private System.Windows.Forms.Button FuncPesquisa;
        private System.Windows.Forms.Button NovoFunc;
        private System.Windows.Forms.ComboBox PesquisaFuncTxt;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button AlterarFotoFunc;
        private System.Windows.Forms.Button AlterarImagemAluno;
    }
}

